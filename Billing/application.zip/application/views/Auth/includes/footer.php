<div class="footer">
	<div class="pull-right">
			Designed By <strong><a href='http://dreamanimators.com/' target='_blank'>Dream Animators</a></strong>
	</div>
	<div>
			<strong><?= '&copy; '.$global_data['footer_title'].' | '.date('Y'); ?></strong>
	</div>
</div>