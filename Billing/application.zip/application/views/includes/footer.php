<div class="footer">
	<div class="text-center">
			<span class="pull-right">Designed By <strong><a href='http://dreamanimators.com/' target='_blank'>Dream Animators</a></strong></span>
			<span  class="pull-left">Page rendered in <strong>{elapsed_time}</strong> seconds.</span>
        <b>Press <kbd>Alt+h</kbd> to Switch Between Languages</b>
	</div>
</div>