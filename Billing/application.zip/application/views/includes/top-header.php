<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?= base_url('/public/css/bootstrap.min.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/font-awesome/css/font-awesome.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/iCheck/custom.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/switchery/switchery.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/datapicker/datepicker3.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/select2/select2.min.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/chosen/bootstrap-chosen.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/footable/footable.core.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/sweetalert/sweetalert.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/textSpinners/spinners.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/toastr/toastr.min.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/blueimp/css/blueimp-gallery.min.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/summernote/summernote-bs4.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/plugins/dataTables/datatables.min.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/animate.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/style.css'); ?>" rel="stylesheet">
<link href="<?= base_url('/public/css/custom.css?v=1.0'); ?>" rel="stylesheet">